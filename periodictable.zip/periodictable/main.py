import customtkinter as ctk
from periodictable import PeriodicTable
from periodictable import CTkElement
from pprint import pprint

# element = PeriodicTable('o')
# pprint(element.name())

def change():
    g = entry.get()
    element.rename(element = g)

app = ctk.CTk()
app.geometry('500x500')
app.title('Tableau periodique')

element = CTkElement(app, element = 'vanadium', textsize = 60)
element.pack(pady = 20)

entry = ctk.CTkEntry(app, width = 250)
entry.pack()

btn = ctk.CTkButton(app, text = 'press', command = change)
btn.pack(pady = 10)

app.mainloop()