from os.path import isfile, realpath, dirname
from pprint import pprint
from glob import glob
import customtkinter
import json


class PeriodicTable:
    def __init__(self, element_name = None):
        self.__element_name = element_name.lower().replace('è', 'e').replace('é', 'e') if element_name else ''

        __file_dir_path = dirname(realpath(__file__))
        __element_files = __file_dir_path + '/data/'
        __files_path = [files for files in glob(__element_files + '*.json')]
        self.__elements = {}
        for file_path in __files_path:
            if isfile(file_path):
                with open(file_path, encoding = 'utf-8') as file:
                    element_info = json.load(file)

                    if element_info.get('name', None):
                        self.__elements[element_info['name'].lower().replace('è', 'e').replace('é', 'e')] = element_info

                        if self.__element_name in map(lambda an: an.lower(), element_info.get('symbole', [])):
                            self.__element_name = element_info['name'].lower().replace('è', 'e').replace('é', 'e')

    def info(self):
        try:
            if self.__element_name:
                _all = self.__elements[self.__element_name]
                return _all
        except KeyError:
            return []
    
    def atomicmass(self):
        if self.__element_name:
            _atomicmass = self.__elements[self.__element_name]['atomicmass']
            return _atomicmass

    def name(self):
        if self.__element_name:
            try:
                _name = self.__elements[self.__element_name]['name']
                return _name
            except KeyError:
                return []

    def symbole(self):
        if self.__element_name:
            try:
                _alt_spellings = self.__elements[self.__element_name]['symbole']
                return _alt_spellings
            except KeyError:
                return [] 
    
    def atomicnumber(self):
        try:
            if self.__element_name:
                _atomicnumber = self.__elements[self.__element_name]['atomicnumber']
                return _atomicnumber
        except KeyError:
            return []
    
    def molarmass(self):
        try:
            if self.__element_name:
                _molarmass = self.__elements[self.__element_name]['molarmass']
                return _molarmass
        except KeyError:
            return []
    
    def density(self):
        try:
            if self.__element_name:
                _density = self.__elements[self.__element_name]['density']
                return _density
        except KeyError:
            return []
    
    def valence(self):
        try:
            if self.__element_name:
                _valence = self.__elements[self.__element_name]['valence']
                return _valence
        except KeyError:
            return []
    
    def period(self):
        try:
            if self.__element_name:
                _period = self.__elements[self.__element_name]['period']
                return _period 
        except KeyError:
            return []
    
    def group(self):
        try:
            if self.__element_name:
                _group = self.__elements[self.__element_name]['group']
                return _group
        except KeyError:
            return []
        
    def phase(self):
        try:
            if self.__element_name:
                _phase = self.__elements[self.__element_name]['phase']
                return _phase
        except KeyError:
            return []
    
    def constitution(self):
        try:
            if self.__element_name:
                _config = self.__elements[self.__element_name]['configuration']
                return _config
        except KeyError:
            return []
    
    def year(self):
        try:
            if self.__element_name:
                _year = self.__elements[self.__element_name]['year']
                return _year
        except KeyError:
            return []
    
    def discoverer(self):
        try:
            if self.__element_name:
                _discoveredname = self.__elements[self.__element_name]['discoveredname']
                return _discoveredname
        except KeyError:
            return []
    
    def electronicstructure(self):
        try:
            if self.__element_name:
                _electronicstructure = self.__elements[self.__element_name]['electronicstructure']
                return _electronicstructure
        except KeyError:
            return []
    
    def radioactive(self):
        try:
            if self.__element_name:
                _radioactive = self.__elements[self.__element_name]['radioactive']
                return _radioactive
        except KeyError:
            return []
    
    def all(self):
        _all = self.__elements
        return _all

"""
Création d'un widget qui permet d'avoir différents informations pour chaque élément.
J'ai utilisé une Frame customtkinter.
"""
class CTkElement(customtkinter.CTkFrame):
    def __init__(self, master, element = 'hydrogene', width = None, height = None, textsize = None, *args, **kwargs):
        self.element = element
        if self.element == '':
            self.element = 'hydrogene'

        super().__init__(master = master, *args, **kwargs)
        #\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
        #-------------Redimensionnement-------------------------
        #\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

        """
        Redimensionnement automatique de la Frame. 
        la grandeur en largeur se trouve entre : 100 - 150 et la hauteur entre 180 - 200.
        """
        if width is not None:
            self.initial_width = width
            if self.initial_width > 150:
                self.initial_width = 150
            elif self.initial_width < 100:
                self.initial_width = 100
            else:
                pass

            if height is not None:
                self.initial_height = height
                if self.initial_height > 200:
                    self.initial_height = 200
                elif self.initial_height < 180:
                    self.initial_height = 180
                else:
                    pass
        #\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
        #-------------Redimensionnement-------------------------
        #\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
        
        self.initial_height = 200 #--------->         200   Height min de la Frame
        self.initial_width = 150  #------------->     150  Width min de la Frame
        self.hover_width = 400    #-----------------> 400  Width max de la Frame
        self.hover_height = 300   #-----------------> 300  Height max de la Frame

        self.configure(width = self.initial_width, height = self.initial_height, corner_radius = 1, fg_color = '#31343d')

        elements = PeriodicTable(self.element)

        #---------------------------------------------------------------------------------------------
        #----------------------ScrollableFrame_pour_differents_inforamtion----------------------------
        #---------------------------------------------------------------------------------------------
        self.scrollframe = customtkinter.CTkScrollableFrame(self, width = 170, height = 150, corner_radius = 15, 
            label_text = elements.constitution(), fg_color = '#1c1f26', label_font = ('Century Gothic', 10))
        self.scrollframe.place(x = 190, y = 5)

        self.annee = customtkinter.CTkLabel(self.scrollframe, text = (f'Année de découverte :\n{elements.year()}'), 
            font = ('Century Gothic', 13), text_color = 'white', justify = 'left')
        self.annee.pack(anchor = 'w')
        self.separator = customtkinter.CTkFrame(self.scrollframe, height = 2, fg_color = 'gray')
        self.separator.pack(pady = 5, fill = 'x')
        
        liste = elements.discoverer()
        texte = '\n'.join(liste)
        self.discover = customtkinter.CTkLabel(self.scrollframe, text = str(f'Découvert par :\n{texte}'), 
            font = ('Century Gothic', 9), text_color = 'white', justify = 'left')
        self.discover.pack(anchor = 'w')
        self.separator = customtkinter.CTkFrame(self.scrollframe, height = 2, fg_color = 'gray')
        self.separator.pack(pady = 5, fill = 'x')

        self.structure = customtkinter.CTkLabel(self.scrollframe, text = (f'Configuration électronique:\n{elements.electronicstructure()}'), 
            font = ('Century Gothic', 12), text_color = 'white', justify = 'left')
        self.structure.pack(anchor = 'w')
        self.separator = customtkinter.CTkFrame(self.scrollframe, height = 2, fg_color = 'gray')
        self.separator.pack(pady = 5, fill = 'x')
        

        self.molarmass = customtkinter.CTkLabel(self.scrollframe, text = (f'Masse molaire:\n{elements.molarmass()}'), 
            font = ('Century Gothic', 13), text_color = 'white', justify = 'left')
        self.molarmass.pack(anchor = 'w')
        self.separator = customtkinter.CTkFrame(self.scrollframe, height = 2, fg_color = 'gray')
        self.separator.pack(pady = 5, fill = 'x')

        self.density = customtkinter.CTkLabel(self.scrollframe, text = (f'Masse volumique:\n{elements.density()}'), 
            font = ('Century Gothic', 13), text_color = 'white', justify = 'left')
        self.density.pack(anchor = 'w')
        self.separator = customtkinter.CTkFrame(self.scrollframe, height = 2, fg_color = 'gray')
        self.separator.pack(pady = 5, fill = 'x')

        liste_valence = elements.valence()
        texte_valence = '\n'.join(liste_valence)
        self.valence = customtkinter.CTkLabel(self.scrollframe, text = str(f'Valence :\n{texte_valence}'), 
            font = ('Century Gothic', 13), text_color = 'white', justify = 'left')
        self.valence.pack(anchor = 'w')
        self.separator = customtkinter.CTkFrame(self.scrollframe, height = 2, fg_color = 'gray')
        self.separator.pack(pady = 5, fill = 'x')

        self.period = customtkinter.CTkLabel(self.scrollframe, text = (f'Periode :\n{elements.period()}'), 
            font = ('Century Gothic', 13), text_color = 'white', justify = 'left')
        self.period.pack(anchor = 'w')
        self.separator = customtkinter.CTkFrame(self.scrollframe, height = 2, fg_color = 'gray')
        self.separator.pack(pady = 5, fill = 'x')

        self.group = customtkinter.CTkLabel(self.scrollframe, text = (f'Groupe :\n{elements.group()}'), 
            font = ('Century Gothic', 13), text_color = 'white', justify = 'left')
        self.group.pack(anchor = 'w')
        self.separator = customtkinter.CTkFrame(self.scrollframe, height = 2, fg_color = 'gray')
        self.separator.pack(pady = 5, fill = 'x')

        self.phase = customtkinter.CTkLabel(self.scrollframe, text = (f'Phase :\n{elements.phase()}'), 
            font = ('Century Gothic', 13), text_color = 'white', justify = 'left')
        self.phase.pack(anchor = 'w')
        self.separator = customtkinter.CTkFrame(self.scrollframe, height = 2, fg_color = 'gray')
        self.separator.pack(pady = 5, fill = 'x')

        self.radioactive = customtkinter.CTkLabel(self.scrollframe, text = (f'Radioactif :\n{elements.radioactive()}'), 
            font = ('Century Gothic', 13), text_color = 'white', justify = 'left')
        self.radioactive.pack(anchor = 'w')
        self.separator = customtkinter.CTkFrame(self.scrollframe, height = 2, fg_color = 'gray')
        self.separator.pack(pady = 5, fill = 'x')

        # self.structure.bind('<Enter>', self.show_information)
        # self.discover.bind('<Enter>', self.show_information)
        # self.annee.bind('<Enter>', self.show_information)
        # self.separator.bind('<Enter>', self.show_information)
        # self.density.bind('<Enter>', self.show_information)
        # self.valence.bind('<Enter>', self.show_information)
        # self.period.bind('<Enter>', self.show_information)
        # self.group.bind('Enter', self.show_information)
        # self.phase.bind('Enter', self.show_information)
        # self.radioactive.bind('Enter', self.show_information)
        self.scrollframe.bind('<Enter>', self.show_information)
        
        #---------------------------------------------------------------------------------------------------------
        #----------------------ScrollableFrame_pour_differents_inforamtion----------------------------
        #---------------------------------------------------------------------------------------------------------

        self.symbole = customtkinter.CTkLabel(self, text = str(elements.symbole()[0]), font = ('Arial', 90), text_color = 'white')
        self.symbole.place(relx = 0.03, rely = 0.15)

        self.names = customtkinter.CTkLabel(self, text = str(elements.name()), font = ('Century Gothic', 20), text_color = 'white')
        self.names.place(relx = 0.03, rely = 0.58)

        self.atn = customtkinter.CTkLabel(self, text = str(elements.atomicnumber()), font = ('Century Gothic', 30), text_color = 'white')
        self.atn.place(relx = 0.03, rely = 0.01)

        self.atm = customtkinter.CTkLabel(self, text = str(elements.atomicmass()[:-7]), font = ('Century Gothic', 17), text_color = 'white')
        self.atm.place(relx = 0.03, rely = 0.83)

        # Calcul pour redimensionner la taille de la police
        if textsize is not None:
            size = int(textsize)                
            size2 = int((((textsize - 20)/5)+5)) 
            size3 = int(((textsize - 30)/3)+7)   
            size4 = int((((textsize - 17)/5)+3)) 
            # print(f'{size}\n{size2}\n{size3}\n{size4}')

            self.symbole.configure(font = ('Arial', size))
            self.names.configure(font = ('Century Gothic', size2))
            self.atn.configure(font = ('Century Gothic', size3))
            self.atm.configure(font = ('Century Gothic', size4))

        else:
            pass

        self.color = customtkinter.CTkFrame(self, width = 400, height = 10, fg_color = '#ea7904', corner_radius = 1)
        self.color.place(relx = 0.5, rely = 1.05, anchor = 's', y = -10)

        if elements.constitution().lower() == 'non metaux':
            self.color.configure(fg_color = '#ea7904')
        elif elements.constitution().lower() == 'metaux alcalins':
            self.color.configure(fg_color = '#da4004')
        elif elements.constitution().lower() == 'gaz rares':
            self.color.configure(fg_color = '#b34dd9')
        elif elements.constitution().lower() == 'semi-conducteurs' or 'semi-conducteur':
            self.color.configure(fg_color = '#7f92ff')
        elif elements.constitution().lower() == 'lanthanides':
            self.color.configure(fg_color = '#d6572d')
        elif elements.constitution().lower() == 'metaux alcalino-terreux':
            self.color.configure(fg_color = '#45b2ff')
        elif elements.constitution().lower() == 'metaux de transition':
            self.color.configure(fg_color = '#ea7724')
        elif elements.constitution().lower() == 'halogenes':
            self.color.configure(fg_color = '#43b854')
        elif elements.constitution().lower() == 'metalloide' or 'metalloides':
            self.color.configure(fg_color = '#f23f54')
        elif elements.constitution().lower() == 'superactinides':
            self.color.configure(fg_color = 'white')
        elif elements.constitution().lower() == 'actinides':
            self.color.configure(fg_color = '#549e77')
        else:
            self.color.configure(fg_color = 'gray')

        
        self.color.bind('<Enter>', self.show_information)
        self.color.bind('<Leave>', self.hide_information)
        
        self.bind('<Enter>', self.show_information)
        self.bind('<Leave>', self.hide_information)
        
    def show_information(self, event):
        self.animate(self.hover_width, self.hover_height)
        self.color.place(relx = 0.5, rely = 1.05, anchor = 's', y = -10)
        
        self.names.place(relx = 0.03, rely = 0.43)
        self.atm.place(relx = 0.03, rely = 0.53)

    def hide_information(self, event):
        self.animate(self.initial_width, self.initial_height)
        self.color.place(relx = 0.5, rely = 1.05, anchor = 's', y = -10)

        self.names.place(relx = 0.03, rely = 0.58)
        self.atm.place(relx = 0.03, rely = 0.83)
        
    def animate(self, target_width, target_height):
        def animation():
            new_width = min(target_width, self.winfo_width() + 10)
            new_height = min(target_height, self.winfo_height() + 10)
            self.configure(width = new_width, height = new_height)

            if new_width < target_width or new_height < target_height:
                self.after(10, animation)
        
        animation()
         
    def rename(self, element = None):
        self.element = element
        if self.element is not None:
            elements = PeriodicTable(self.element)
            
            self.scrollframe.configure(label_text = elements.constitution())
            self.annee.configure(text = (f'Année de découverte :\n{elements.year()}'))

            liste = elements.discoverer()
            texte = '\n'.join(liste)
            self.discover.configure(text = str(f'Découvert par :\n{texte}'))
            self.structure.configure(text = (f'Configuration électronique:\n{elements.electronicstructure()}'))
            self.molarmass.configure(text = (f'Masse molaire:\n{elements.molarmass()}'))
            self.density.configure(text = (f'Masse volumique:\n{elements.density()}'))

            liste_valence = elements.valence()
            texte_valence = '\n'.join(liste_valence)
            self.valence.configure(text = str(f'Valence :\n{texte_valence}'))
            self.period.configure(text = (f'Periode :\n{elements.period()}'))
            self.group.configure(text = (f'Groupe :\n{elements.group()}'))
            self.phase.configure(text = (f'Phase :\n{elements.phase()}'))
            self.radioactive.configure(text = (f'Radioactif :\n{elements.radioactive()}'))

            
            self.symbole.configure(text = str(elements.symbole()[0]))
            self.names.configure(text = str(elements.name()))
            self.atn.configure(text = str(elements.atomicnumber()))
            self.atm.configure(text = str(elements.atomicmass()[:-7]))
            
            if elements.constitution().lower() == 'non metaux':
                self.color.configure(fg_color = '#ea7904')
            elif elements.constitution().lower() == 'metaux alcalins':
                self.color.configure(fg_color = '#da4004')
            elif elements.constitution().lower() == 'gaz rares':
                self.color.configure(fg_color = '#b34dd9')
            elif elements.constitution().lower() == 'semi-conducteurs' or 'semi-conducteur':
                self.color.configure(fg_color = '#7f92ff')
            elif elements.constitution().lower() == 'lanthanides':
                self.color.configure(fg_color = '#d6572d')
            elif elements.constitution().lower() == 'metaux alcalino-terreux':
                self.color.configure(fg_color = '#45b2ff')
            elif elements.constitution().lower() == 'metaux de transition':
                self.color.configure(fg_color = '#ea7724')
            elif elements.constitution().lower() == 'halogenes':
                self.color.configure(fg_color = '#43b854')
            elif elements.constitution().lower() == 'metalloide' or 'metalloides':
                self.color.configure(fg_color = '#f23f54')
            elif elements.constitution().lower() == 'superactinides':
                self.color.configure(fg_color = 'white')
            elif elements.constitution().lower() == 'actinides':
                self.color.configure(fg_color = '#549e77')
            else:
                self.color.configure(fg_color = 'gray')

if __name__=='__main__':
    element = PeriodicTable('Hydrogen')
    pprint(element.all())

